<hr class="section-break">
<h2 class="headline headline--medium"><?php echo get_the_title(); ?><?php echo ucfirst($args['post_type']) . '(s)'; ?></h2>